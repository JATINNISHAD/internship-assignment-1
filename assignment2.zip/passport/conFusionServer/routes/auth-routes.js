const express = require('express');
const routes = express.Router();
const passport = require('passport');


routes.route('/login')
.get((req,res)=>{
    res.statusCode=200;
    res.render('login',{user:req.user});
});

routes.route('/logout')
.get((req,res)=>{
    req.logout();
    res.redirect('/');
});

routes.get('/google',passport.authenticate('google',{
    scope:['profile']
}));

routes.get('/google/redirect',passport.authenticate('google'),(req,res)=>{
    res.statusCode = 200;
    res.redirect('/profile/');
});

module.exports = routes;