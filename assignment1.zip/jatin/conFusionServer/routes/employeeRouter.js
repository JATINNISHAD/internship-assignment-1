const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const employees = require('../models/employees');
const employeeRouter = express.Router();

employeeRouter.use(bodyParser.json());

employeeRouter.route('/')
.get((req,res,next)=>{
    employees.find({})
    .then((employees)=>{
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.json(employees);
    },(err)=>next(err))
    .catch((err)=>next(err));
})
.post((req, res, next) => {
    employees.create(req.body)
    .then((employee) => {
        console.log('employee registered ', employee);
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.json(employee);
    }, (err) => next(err))
    .catch((err) => next(err));
})
.put((req, res, next) => {
    res.statusCode = 403;
    res.end('Put operation Not Supported on /employees');
})
.delete((req,res,next)=>{
    employees.remove({})
    .then((resp)=>{
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.json(resp);
    },(err)=>next(err))
    .catch((err)=>next(err));
});

employeeRouter.route('/:employeeId')
.get((req,res,next)=>{
    employees.findById(req.params.employeeId)
    .then((employee)=>{
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.json(employee);
    },(err)=>{
        var err = new Error('This employee id doesn\'t exists');
        err.status = 404;
        next(err);
    })
    .catch((err)=>next(err));
})
.post((req,res,next)=>{
    res.statusCode = 403;
    res.end('Post operation not Supported on /employees/'+req.params.employeeId);
})
.put((req,res,next)=>{
    employees.findByIdAndUpdate(req.params.employeeId,{$set:req.body},{new:true})
    .then((employee)=>{
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.json(employee);
    },(err)=>{
        var err = new Error('This employee id doesn\'t exists');
        err.status = 404;
        next(err);
    })
    .catch((err)=>next(err));
})
.delete((req,res,next)=>{
    employees.findByIdAndRemove(req.params.employeeId)
    .then((resp)=>{
        res.statusCode = 200;
        res.setHeader('Content-Type','application/json');
        res.json(resp);
    },(err)=>{
        var err = new Error('This employee id doesn\'t exists');
        err.status = 404;
        next(err);
    })
    .catch((err)=>next(err));
});

module.exports = employeeRouter;



















