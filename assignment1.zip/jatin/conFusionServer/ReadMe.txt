#assignment1

hii there, My name is Jatin

this Assignment's purpose is to show the CRUD operations 

here i have used express generator tool to create a simple classic structure for the express application //saves time .

this express application contains some of the most common third party packages . You can install them by "npm install"

Use desired packages and u can delete or uninstall non-required packages .

AS PER THE ASSIGNMENT 1(PERFORM CRUD OPERATIONS WITH NODEJS AND MONGODB):- 

To show the CRUD operation i have made web app which stores employee name and department .
1) in the models folder > "employees.js" contains the Schema for the employees Data .
2) in the routes folder > "employeeRouter.js" contains the list of CRUD of CRUD operations to be performed. i.e GET,PUT(update),POST,DELETE 
3) the File "app.js" we have declared various required packages for the this web app

    mongoose is used to connect and perform various operation on the DATABASE(mongodb)

    i tried to make it simple and classy, 

    To test all desired CRUD operations you can use "POSTMAN" to test the working of the web-app, but before that dont forget to add DataBase 
    to it. I have used local mongodb server for it ,You can test it by connecting ur database with it , only you have to do is create a
    database with name "conFusion" and bind it.

    Run the mongodb server 
    and in the project folder's terminal type "npm start" to run app.js //server  

    http://localhost:3000/employees

    http://localhost:3000/employees/employeeId 

                                        employeeId={id provided my mongodb}

    if everything works successfull you can perform all the CRUD operations.

Note:  my focus was only on the back-end operations of this app , thats why i havent used frontend for it . 



Thankyou


